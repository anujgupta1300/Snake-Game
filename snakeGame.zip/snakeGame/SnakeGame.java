import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.LinkedList;
import java.util.Random;
import javax.imageio.ImageIO;
import javax.swing.*;

public class SnakeGame extends JPanel implements ActionListener, KeyListener {
    private final int boardWidth;
    private final int boardHeight;
    private final int UNIT_SIZE = 25;
    private final int DELAY = 80;

    private final LinkedList<Point> snake = new LinkedList<>();
    private Point food;
    private char direction = 'R';
    private boolean running = false;
    private Timer timer;
    private int score = 0;
    private boolean gameOver = false;

    private JLabel scoreLabel;
    private JButton startButton, restartButton;
    private JPanel overlayPanel;
    private BufferedImage snakeHeadImg;
    private BufferedImage appleImg;
    private BufferedImage specialAppleImg;

    private Point specialApple = null;
    private boolean showSpecialApple = false;
    private int specialAppleTimer = 0;
    private final int SPECIAL_APPLE_DURATION = 50; 
    private final int SPECIAL_APPLE_CHANCE = 20; 

    public SnakeGame(int width, int height) {
        this.boardWidth = width;
        this.boardHeight = height;

        setPreferredSize(new Dimension(boardWidth, boardHeight));
        setBackground(new Color(24, 26, 32));
        setLayout(null);
        setFocusable(true);
        addKeyListener(this);

        
        overlayPanel = new JPanel();
        overlayPanel.setLayout(null);
        overlayPanel.setOpaque(false);
        overlayPanel.setBounds(0, 0, boardWidth, boardHeight);
        add(overlayPanel);

        
        scoreLabel = new JLabel("Score: 0");
        scoreLabel.setFont(new Font("Segoe UI", Font.BOLD, 22));
        scoreLabel.setForeground(new Color(255, 255, 255, 230));
        scoreLabel.setBounds(30, 20, 200, 40);
        overlayPanel.add(scoreLabel);

        
        startButton = createModernButton("Start");
        startButton.setBounds(boardWidth / 2 - 90, boardHeight / 2 - 50, 180, 50);
        startButton.addActionListener(e -> startGame());
        overlayPanel.add(startButton);

       
        restartButton = createModernButton("Restart");
        restartButton.setBounds(boardWidth / 2 - 90, boardHeight / 2 + 10, 180, 50);
        restartButton.addActionListener(e -> restartGame());
        restartButton.setVisible(false);
        overlayPanel.add(restartButton);

        initGame();
    }

    private JButton createModernButton(String text) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 20));
        btn.setBackground(new Color(0, 180, 120, 220));
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setContentAreaFilled(false);
        btn.setOpaque(true);
        btn.setBorder(BorderFactory.createLineBorder(new Color(0, 180, 120), 2, true));
        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btn.setBackground(new Color(0, 220, 160, 240));
                btn.setBorder(BorderFactory.createLineBorder(new Color(0, 220, 160), 2, true));
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btn.setBackground(new Color(0, 180, 120, 220));
                btn.setBorder(BorderFactory.createLineBorder(new Color(0, 180, 120), 2, true));
            }
        });
        return btn;
    }

    private void initGame() {
        snake.clear();
        snake.add(new Point(UNIT_SIZE * 4, UNIT_SIZE * 4));
        direction = 'R';
        score = 0;
        updateScore();
        placeFood();
        running = false;
        gameOver = false;
        if (timer != null) timer.stop();
        startButton.setVisible(true);
        restartButton.setVisible(false);
        repaint();
    }

    private void startGame() {
        running = true;
        gameOver = false;
        startButton.setVisible(false);
        restartButton.setVisible(false);
        timer = new Timer(DELAY, this);
        timer.start();
        requestFocusInWindow();
    }

    private void restartGame() {
        initGame();
        running = true;
        gameOver = false;
        startButton.setVisible(false);
        restartButton.setVisible(false);
        timer = new Timer(DELAY, this);
        timer.start();
        requestFocusInWindow();
    }

    private void placeFood() {
        Random rand = new Random();
        int x = rand.nextInt(boardWidth / UNIT_SIZE) * UNIT_SIZE;
        int y = rand.nextInt(boardHeight / UNIT_SIZE) * UNIT_SIZE;
        food = new Point(x, y);
        while (snake.contains(food)) {
            x = rand.nextInt(boardWidth / UNIT_SIZE) * UNIT_SIZE;
            y = rand.nextInt(boardHeight / UNIT_SIZE) * UNIT_SIZE;
            food = new Point(x, y);
        }
    }

    private void placeSpecialApple() {
        Random rand = new Random();
        Point newApple;
        do {
            int x = rand.nextInt(boardWidth / UNIT_SIZE) * UNIT_SIZE;
            int y = rand.nextInt(boardHeight / UNIT_SIZE) * UNIT_SIZE;
            newApple = new Point(x, y);
        } while (snake.contains(newApple) || newApple.equals(food));
        specialApple = newApple;
        showSpecialApple = true;
        specialAppleTimer = SPECIAL_APPLE_DURATION;
        if (specialAppleImg == null) {
            try {
                specialAppleImg = ImageIO.read(new File("Image/Apple.png"));
            } catch (IOException e) {
                specialAppleImg = null;
            }
        }
        repaint(); 
    }

    
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        drawBackgroundText(g);
        drawGame(g);
    }

    private void drawBackgroundText(Graphics g) {
        Graphics2D g2d = (Graphics2D) g.create();
        g2d.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        String name = "ANUJ";
        g2d.setFont(new Font("Segoe UI", Font.BOLD, 150));
        g2d.setColor(new Color(255, 255, 255, 22));
        FontMetrics fm = g2d.getFontMetrics();
        int x = (boardWidth - fm.stringWidth(name)) / 2;
        int y = (boardHeight + fm.getAscent()) / 2 - 70;
        g2d.drawString(name, x, y);
        g2d.dispose();
    }

    private void drawGame(Graphics g) {
        Graphics2D g2d = (Graphics2D) g.create();
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        
        if (appleImg != null) {
            g2d.drawImage(appleImg, food.x, food.y, UNIT_SIZE, UNIT_SIZE, this);
        } else {
            
            int shadowOffset = 2;
            g2d.setColor(new Color(255, 120, 60, 80));
            g2d.fillRoundRect(food.x + shadowOffset, food.y + shadowOffset, UNIT_SIZE, UNIT_SIZE, 16, 16);
            GradientPaint foodGradient = new GradientPaint(
                food.x, food.y, new Color(255, 180, 80),
                food.x + UNIT_SIZE, food.y + UNIT_SIZE, new Color(255, 80, 80)
            );
            g2d.setPaint(foodGradient);
            g2d.fillRoundRect(food.x, food.y, UNIT_SIZE, UNIT_SIZE, 16, 16);
        }

        
        if (showSpecialApple && specialApple != null) {
            if (specialAppleImg != null) {
                int size = (int) (UNIT_SIZE * 1.8); 
                int offset = (size - UNIT_SIZE) / 2;
                g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
                g2d.drawImage(specialAppleImg, specialApple.x - offset, specialApple.y - offset, size, size, this);
            }
        }

        
        for (int i = 0; i < snake.size(); i++) {
            Point p = snake.get(i);
            if (i == 0) {
                if (snakeHeadImg != null) {
                    g2d.drawImage(snakeHeadImg, p.x, p.y, UNIT_SIZE, UNIT_SIZE, this);
                } else {
                    g2d.setPaint(new GradientPaint(
                        p.x, p.y, new Color(0, 255, 120),
                        p.x + UNIT_SIZE, p.y + UNIT_SIZE, new Color(0, 180, 80)
                    ));
                    g2d.fillRoundRect(p.x, p.y, UNIT_SIZE, UNIT_SIZE, 16, 16);
                }
            } else {
                g2d.setPaint(new GradientPaint(
                    p.x, p.y, new Color(0, 200, 120),
                    p.x + UNIT_SIZE, p.y + UNIT_SIZE, new Color(0, 120, 80)
                ));
                g2d.fillRoundRect(p.x, p.y, UNIT_SIZE, UNIT_SIZE, 14, 14);
            }
        }
        g2d.dispose();

        
        if (gameOver) {
            showGameOver();
        }
    }

    private void showGameOver() {
        Graphics2D g2d = (Graphics2D) getGraphics();
        if (g2d == null) return;
        g2d.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

        String msg = "Game Over";
        String hint = "Press 'R' to Restart";
        g2d.setFont(new Font("Segoe UI", Font.BOLD, 54));
        g2d.setColor(new Color(255, 80, 80, 230));
        FontMetrics metrics = g2d.getFontMetrics();
        g2d.drawString(msg, (boardWidth - metrics.stringWidth(msg)) / 2, boardHeight / 2 - 60);

        g2d.setFont(new Font("Segoe UI", Font.PLAIN, 28));
        g2d.setColor(new Color(255, 255, 255, 200));
        FontMetrics metrics2 = g2d.getFontMetrics();
        g2d.drawString(hint, (boardWidth - metrics2.stringWidth(hint)) / 2, boardHeight / 2 - 10);

        restartButton.setVisible(true);
        g2d.dispose();
    }

    private void move() {
        Point head = new Point(snake.getFirst());
        switch (direction) {
            case 'U': head.y -= UNIT_SIZE; break;
            case 'D': head.y += UNIT_SIZE; break;
            case 'L': head.x -= UNIT_SIZE; break;
            case 'R': head.x += UNIT_SIZE; break;
        }
        snake.addFirst(head);

        if (head.equals(food)) {
            score++;
            updateScore();
            placeFood();
            
            if (!showSpecialApple && new Random().nextInt(SPECIAL_APPLE_CHANCE) == 0) {
                placeSpecialApple();
            }
        } else if (showSpecialApple && head.equals(specialApple)) {
            score += 3;
            updateScore();
            showSpecialApple = false;
            specialApple = null;
        } else {
            snake.removeLast();
        }
    }

    private void checkCollision() {
        Point head = snake.getFirst();
        
        if (head.x < 0 || head.x >= boardWidth || head.y < 0 || head.y >= boardHeight) {
            running = false;
            gameOver = true;
        }
        
        for (int i = 1; i < snake.size(); i++) {
            if (head.equals(snake.get(i))) {
                running = false;
                gameOver = true;
                break;
            }
        }
        if (gameOver) {
            timer.stop();
            restartButton.setVisible(true);
            repaint();
        }
    }

    private void updateScore() {
        scoreLabel.setText("Score: " + score);
    }

    
    public void actionPerformed(ActionEvent e) {
        if (running) {
            move();
            checkCollision();
            
            if (showSpecialApple) {
                specialAppleTimer--;
                if (specialAppleTimer <= 0) {
                    showSpecialApple = false;
                    specialApple = null;
                }
            }
        }
        repaint();
    }

    
    public void keyPressed(KeyEvent e) {
        if (running) {
            switch (e.getKeyCode()) {
                case KeyEvent.VK_LEFT:
                    if (direction != 'R') direction = 'L';
                    break;
                case KeyEvent.VK_RIGHT:
                    if (direction != 'L') direction = 'R';
                    break;
                case KeyEvent.VK_UP:
                    if (direction != 'D') direction = 'U';
                    break;
                case KeyEvent.VK_DOWN:
                    if (direction != 'U') direction = 'D';
                    break;
            }
        } else if (gameOver && e.getKeyCode() == KeyEvent.VK_R) {
            restartGame();
        }
    }

    
    public void keyReleased(KeyEvent e) {}
    
    public void keyTyped(KeyEvent e) {}
}
