import java.awt.Image;
import javax.imageio.ImageIO;
import java.io.File;
import javax.swing.*;

public class App {
    public static void main(String[] args) throws Exception {
        int boardWidth = 600;
        int boardHeight = boardWidth;

        JFrame frame = new JFrame("A-J Snake");
        try {
            Image icon = ImageIO.read(new File("Image/Shead.png"));
            frame.setIconImage(icon);
        } catch (Exception ex) {
            System.out.println("Icon not found: " + ex.getMessage());
        }
        frame.setVisible(true);
	    frame.setSize(boardWidth, boardHeight);
        frame.setLocationRelativeTo(null);
        frame.setResizable(false);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        SnakeGame snakeGame = new SnakeGame(boardWidth, boardHeight);
        frame.add(snakeGame);
        frame.pack();
        snakeGame.requestFocus();
    }
}
